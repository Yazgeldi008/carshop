document.addEventListener("DOMContentLoaded", function () {
    console.log("CarShop sahypasy ýüklenildi!");
});